package root.GuiController;

public class GuiController {//leverages node controller, items are added after instantiated by gui form/loading of cfg file


}